import OpenAI from 'openai';

// Initialize OpenAI client only on the server side
let openai: OpenAI | null = null;

export interface TarotReadingRequest {
  layout: string;
  question: string;
  cards: string[];
  image?: File;
}

function getOpenAIClient() {
  if (typeof window !== 'undefined') {
    throw new Error('OpenAI client cannot be initialized on the client side');
  }
  
  if (!openai) {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error('OpenAI API key is not configured');
    }
    openai = new OpenAI({ apiKey });
  }
  
  return openai;
}

export async function generateTarotReading(request: TarotReadingRequest): Promise<string> {
  try {
    // For development/demo purposes, return a mock interpretation
    if (!process.env.OPENAI_API_KEY) {
      return generateMockInterpretation(request);
    }
    
    const client = getOpenAIClient();
    let imageDescription = '';
    
    if (request.image) {
      const imageData = await request.image.arrayBuffer();
      const base64Image = Buffer.from(imageData).toString('base64');
      
      // Get image analysis from GPT-4 Vision
      const visionResponse = await client.chat.completions.create({
        model: "gpt-4-vision-preview",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: "Опишите это изображение в контексте гадания на Таро. Что вы видите, что может быть значимым для интерпретации?" },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/${request.image.type};base64,${base64Image}`,
                },
              },
            ],
          },
        ],
        max_tokens: 500,
      });
      
      imageDescription = visionResponse.choices[0]?.message?.content || '';
    }
    
    // Generate tarot reading with context
    const readingResponse = await client.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        {
          role: "system",
          content: "Вы - опытный таролог, который дает глубокие и проницательные толкования карт Таро. Используйте мистический, но понятный язык. Интерпретируйте значения карт в контексте вопроса и предоставленной информации."
        },
        {
          role: "user",
          content: `Расклад: ${request.layout}
Вопрос: ${request.question}
Карты: ${request.cards.join(', ')}
${imageDescription ? `\nАнализ изображения: ${imageDescription}` : ''}`
        }
      ],
      temperature: 0.7,
      max_tokens: 1000,
    });
    
    return readingResponse.choices[0]?.message?.content || 'Не удалось сгенерировать интерпретацию.';
  } catch (error) {
    console.error('Error generating tarot reading:', error);
    return generateMockInterpretation(request);
  }
}

function generateMockInterpretation(request: TarotReadingRequest): string {
  const interpretations = [
    `В раскладе "${request.layout}" карты ${request.cards.join(', ')} указывают на период важных перемен. ${request.question ? 'Ваш вопрос о ' + request.question + ' находит отражение в энергиях карт.' : ''}`,
    `Карты раскрывают глубокий смысл ситуации. ${request.cards.join(', ')} в совокупности говорят о необходимости внутренней работы и самопознания.`,
    `Расклад показывает интересную комбинацию энергий. ${request.cards.slice(0, 2).join(' и ')} создают особый резонанс, указывающий на скорые перемены.`
  ];
  
  return interpretations[Math.floor(Math.random() * interpretations.length)];
}