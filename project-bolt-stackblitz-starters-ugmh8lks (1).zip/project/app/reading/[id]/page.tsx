"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Navbar } from '@/components/navbar';
import { StarsBackground } from '@/components/ui/stars-background';
import { ReadingResult } from '@/components/reading-result';
import { Button } from '@/components/ui/button';
import { Reading } from '@/lib/tarot-data';
import { ArrowLeft } from 'lucide-react';

// This function tells Next.js which dynamic paths to pre-render
export async function generateStaticParams() {
  // For static export, we'll pre-render a few placeholder IDs
  // In a real app, you would get these from your database
  return [
    { id: 'placeholder-1' },
    { id: 'placeholder-2' },
    { id: 'placeholder-3' }
  ];
}

export default function ReadingDetailPage({ params }: { params: { id: string } }) {
  const [reading, setReading] = useState<Reading | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();
  
  useEffect(() => {
    // Load reading from localStorage
    try {
      const savedReadings = JSON.parse(localStorage.getItem('tarotReadings') || '[]');
      const foundReading = savedReadings.find((r: any) => r.id === params.id);
      
      if (foundReading) {
        // Convert date string back to Date object
        setReading({
          ...foundReading,
          date: new Date(foundReading.date)
        });
      }
    } catch (error) {
      console.error('Error loading reading:', error);
    } finally {
      setIsLoading(false);
    }
  }, [params.id]);
  
  const handleShare = () => {
    // In a real app, this would generate a shareable link
    alert('Функция поделиться будет доступна в ближайшем обновлении.');
  };
  
  if (isLoading) {
    return (
      <main className="min-h-screen flex flex-col">
        <Navbar />
        <StarsBackground />
        <div className="flex-1 flex items-center justify-center">
          <div className="relative w-16 h-16">
            <div className="absolute inset-0 rounded-full border-4 border-secondary/20 border-t-secondary animate-spin"></div>
          </div>
        </div>
      </main>
    );
  }
  
  if (!reading) {
    return (
      <main className="min-h-screen flex flex-col">
        <Navbar />
        <StarsBackground />
        <div className="flex-1 container mx-auto px-4 py-8">
          <div className="max-w-3xl mx-auto text-center py-12">
            <div className="text-4xl mb-4">🔮</div>
            <h1 className="text-2xl font-bold mb-4">Расклад не найден</h1>
            <p className="text-muted-foreground mb-8">
              Запрошенный расклад не существует или был удален
            </p>
            <Link href="/history">
              <Button>Вернуться к истории</Button>
            </Link>
          </div>
        </div>
      </main>
    );
  }
  
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <StarsBackground />
      
      <div className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <div className="mb-6">
            <Button variant="ghost" onClick={() => router.back()} className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Назад
            </Button>
            <h1 className="text-3xl font-bold">Детали расклада</h1>
          </div>
          
          <ReadingResult 
            reading={reading} 
            onShare={handleShare}
          />
        </div>
      </div>
    </main>
  );
}