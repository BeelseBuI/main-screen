"use client";

import { useState, useCallback, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import { Navbar } from '@/components/navbar';
import { StarsBackground } from '@/components/ui/stars-background';
import { SpreadSelector } from '@/components/spread-selector';
import { ReadingResult } from '@/components/reading-result';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { generateReading, Reading } from '@/lib/tarot-data';
import { TarotReadingRequest } from '@/lib/openai';
import { getRandomDelay } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { X, Image as ImageIcon, AlertCircle, Sparkles } from 'lucide-react';

interface UploadedImage {
  file: File;
  preview: string;
  progress: number;
}

export default function ReadingPage() {
  const [selectedSpreadId, setSelectedSpreadId] = useState<string>('');
  const [question, setQuestion] = useState<string>('');
  const [reading, setReading] = useState<Reading | null>(null);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [loadingProgress, setLoadingProgress] = useState<number>(0);
  const [uploadedImages, setUploadedImages] = useState<UploadedImage[]>([]);
  const [uploadError, setUploadError] = useState<string>('');
  const { toast } = useToast();

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isDrawing) {
      // Start progress animation for 120 seconds
      const startTime = Date.now();
      const duration = 120000; // 2 minutes in milliseconds
      
      interval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min((elapsed / duration) * 100, 100);
        setLoadingProgress(progress);
        
        if (progress >= 100) {
          clearInterval(interval);
          handleDrawingComplete();
        }
      }, 100);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isDrawing]);

  const validateImage = (file: File): Promise<boolean> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e) => {
        const img = new Image();
        img.src = e.target?.result as string;
        img.onload = () => {
          if (img.width < 200 || img.height < 200) {
            reject('Изображение должно быть не менее 200x200 пикселей');
            return;
          }
          resolve(true);
        };
      };
    });
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    setUploadError('');
    
    if (uploadedImages.length + acceptedFiles.length > 10) {
      setUploadError('Максимальное количество изображений - 10');
      return;
    }

    const newImages: UploadedImage[] = [];

    for (const file of acceptedFiles) {
      if (file.size > 5 * 1024 * 1024) {
        setUploadError('Размер файла не должен превышать 5MB');
        continue;
      }

      try {
        await validateImage(file);
        
        newImages.push({
          file,
          preview: URL.createObjectURL(file),
          progress: 0
        });
      } catch (error) {
        setUploadError(error as string);
      }
    }

    // Simulate upload progress
    newImages.forEach((image, index) => {
      const interval = setInterval(() => {
        setUploadedImages(prev => prev.map((img, i) => {
          if (i === prev.length - newImages.length + index) {
            const newProgress = Math.min(img.progress + 10, 100);
            return { ...img, progress: newProgress };
          }
          return img;
        }));
      }, 200);

      setTimeout(() => clearInterval(interval), 2000);
    });

    setUploadedImages(prev => [...prev, ...newImages]);
  }, [uploadedImages]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/webp': ['.webp']
    },
    maxSize: 5 * 1024 * 1024, // 5MB
  });

  const removeImage = (index: number) => {
    setUploadedImages(prev => {
      const newImages = [...prev];
      URL.revokeObjectURL(newImages[index].preview);
      newImages.splice(index, 1);
      return newImages;
    });
  };

  const handleSpreadSelect = (spreadId: string) => {
    setSelectedSpreadId(spreadId);
  };

  const handleQuestionChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setQuestion(e.target.value);
  };

  const handleDrawingComplete = async () => {
    try {
      const newReading = generateReading(selectedSpreadId, question);
      
      // Prepare request for OpenAI
      const request: TarotReadingRequest = {
        layout: selectedSpreadId,
        question: question,
        cards: newReading.cards.map(c => c.card.nameRu),
        image: uploadedImages[0]?.file
      };

      // Get AI interpretation
      const response = await fetch('/api/tarot', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(request),
      });

      if (!response.ok) {
        throw new Error('Failed to get interpretation');
      }

      const { interpretation } = await response.json();

      // Update reading with AI interpretation
      const readingWithAI = {
        ...newReading,
        cards: newReading.cards.map(card => ({
          ...card,
          interpretation
        }))
      };

      setReading(readingWithAI);

      // Save to local storage
      const savedReadings = JSON.parse(localStorage.getItem('tarotReadings') || '[]');
      localStorage.setItem('tarotReadings', JSON.stringify([...savedReadings, readingWithAI]));
    } catch (error) {
      toast({
        title: "Ошибка при создании расклада",
        description: "Пожалуйста, попробуйте еще раз.",
        variant: "destructive",
      });
    } finally {
      setIsDrawing(false);
      setLoadingProgress(0);
    }
  };

  const handleDrawCards = () => {
    if (!selectedSpreadId) {
      toast({
        title: "Выберите расклад",
        description: "Пожалуйста, выберите тип расклада перед началом гадания.",
        variant: "destructive",
      });
      return;
    }

    setIsDrawing(true);
  };

  const handleSaveReading = () => {
    if (reading) {
      toast({
        title: "Расклад сохранен",
        description: "Вы можете найти его в разделе 'История'.",
      });
    }
  };

  const handleShareReading = () => {
    if (reading) {
      toast({
        title: "Поделиться раскладом",
        description: "Функция будет доступна в ближайшем обновлении.",
      });
    }
  };

  const handleReset = () => {
    setReading(null);
    setQuestion('');
    setSelectedSpreadId('');
    setUploadedImages([]);
  };

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <StarsBackground />

      <div className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-2">Гадание на Таро</h1>
        <p className="text-muted-foreground text-center mb-8">
          Выберите расклад, задайте вопрос и получите ответ от карт Таро
        </p>

        {isDrawing ? (
          <div className="max-w-2xl mx-auto text-center space-y-8 fade-in">
            <div className="relative">
              <h2 className="text-4xl font-bold text-secondary mb-4">
                <Sparkles className="inline-block mr-2 h-8 w-8" />
                Поиск специалиста
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Расклад готовится...
              </p>
              
              <div className="mt-8 space-y-4">
                <div className="flex space-x-4 justify-center">
                  <div className="loading-circle rounded-full bg-secondary/20 h-12 w-12"></div>
                  <div className="loading-circle rounded-full bg-secondary/20 h-12 w-12"></div>
                  <div className="loading-circle rounded-full bg-secondary/20 h-12 w-12"></div>
                </div>
                
                <p className="text-sm text-muted-foreground italic">
                  Пожалуйста, подождите. Мы соединяемся с картами Таро...
                </p>
              </div>
            </div>
          </div>
        ) : !reading ? (
          <div className="space-y-8 max-w-4xl mx-auto">
            <div>
              <h2 className="text-xl font-semibold mb-4">1. Выберите тип расклада</h2>
              <SpreadSelector
                onSelect={handleSpreadSelect}
                selectedSpreadId={selectedSpreadId}
              />
            </div>

            <div>
              <h2 className="text-xl font-semibold mb-4">2. Задайте вопрос картам</h2>
              <div className="space-y-4">
                <Textarea
                  placeholder="Какой вопрос вы хотите задать картам?"
                  value={question}
                  onChange={handleQuestionChange}
                  className="min-h-[120px]"
                />

                <div
                  {...getRootProps()}
                  className={`border-2 border-dashed rounded-lg p-4 transition-colors ${
                    isDragActive ? 'border-secondary bg-secondary/10' : 'border-border'
                  }`}
                >
                  <input {...getInputProps()} />
                  <div className="flex flex-col items-center justify-center gap-2 text-sm text-muted-foreground">
                    <ImageIcon className="h-8 w-8" />
                    <p>Перетащите изображения сюда или кликните для выбора</p>
                    <p className="text-xs">JPG, PNG, WEBP • До 5MB • Мин. 200x200px • Макс. 10 файлов</p>
                  </div>
                </div>

                {uploadError && (
                  <div className="flex items-center gap-2 text-sm text-destructive">
                    <AlertCircle className="h-4 w-4" />
                    <p>{uploadError}</p>
                  </div>
                )}

                {uploadedImages.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                    {uploadedImages.map((image, index) => (
                      <div key={index} className="relative">
                        <img
                          src={image.preview}
                          alt={`Uploaded ${index + 1}`}
                          className="w-full h-32 object-cover rounded-lg"
                        />
                        <Button
                          variant="destructive"
                          size="icon"
                          className="absolute top-2 right-2 h-6 w-6"
                          onClick={() => removeImage(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                        {image.progress < 100 && (
                          <div className="absolute bottom-2 left-2 right-2">
                            <Progress value={image.progress} className="h-1" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Сформулируйте ясный и конкретный вопрос для более точного ответа.
              </p>
            </div>

            <div className="flex justify-center">
              <Button
                size="lg"
                className="bg-secondary text-secondary-foreground hover:bg-secondary/90"
                onClick={handleDrawCards}
                disabled={isDrawing}
              >
                {isDrawing ? "Подготовка расклада..." : "Разложить карты"}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-8 max-w-5xl mx-auto">
            <ReadingResult
              reading={reading}
              onSave={handleSaveReading}
              onShare={handleShareReading}
              revealDelay={0}
            />

            <div className="flex justify-center">
              <Button
                variant="outline"
                size="lg"
                onClick={handleReset}
              >
                Новое гадание
              </Button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}